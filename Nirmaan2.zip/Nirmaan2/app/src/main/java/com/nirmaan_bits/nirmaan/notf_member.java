package com.nirmaan_bits.nirmaan;

public class notf_member {
    String id;

    public notf_member() {
    }

    public notf_member(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
