package com.nirmaan_bits.nirmaan;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class Attendance_fragment extends Fragment {
    public static int project;

    public Attendance_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_attendance_fragment, container, false);
        TextView gbbaas =view.findViewById(R.id.gbbs);
        TextView gbcb =view.findViewById(R.id.gbcb);
        TextView sap =view.findViewById(R.id.sap);
        TextView pcd =view.findViewById(R.id.pcd);
        TextView sko =view.findViewById(R.id.sko);
        TextView utk = view.findViewById(R.id.utkarsh);
        TextView disha =view.findViewById(R.id.disha);
        TextView un1 =view.findViewById(R.id.un1);
        TextView un2 =view.findViewById(R.id.un2);

        gbbaas.setOnClickListener(new View.OnClickListener(){

                                      @Override
                                      public void onClick(View v){


                                              Fragment newFragment = new Mark_attendance_fragment();
                                              FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack
                                              transaction.replace(R.id.fragment, newFragment);
                                              transaction.addToBackStack(null);
                                          project = 1;

// Commit the transaction
                                              transaction.commit();

                                          }

                                  }


        );
        gbcb.setOnClickListener(new View.OnClickListener(){

                                    @Override
                                    public void onClick(View v){
                                        Fragment newFragment = new Mark_attendance_fragment();
                                        FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack
                                        transaction.replace(R.id.fragment, newFragment);
                                        transaction.addToBackStack(null);
                                        project = 2;

// Commit the transaction
                                        transaction.commit();
                                    }
                                }


        );
        sap.setOnClickListener(new View.OnClickListener(){

                                   @Override
                                   public void onClick(View v){
                                       Fragment newFragment = new Mark_attendance_fragment();
                                       FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack
                                       transaction.replace(R.id.fragment, newFragment);
                                       transaction.addToBackStack(null);
                                       project = 3;

// Commit the transaction
                                       transaction.commit();
                                   }
                               }


        );
        pcd.setOnClickListener(new View.OnClickListener(){

                                   @Override
                                   public void onClick(View v){
                                       Fragment newFragment = new Mark_attendance_fragment();
                                       FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack
                                       transaction.replace(R.id.fragment, newFragment);
                                       transaction.addToBackStack(null);
                                       project = 4;

// Commit the transaction
                                       transaction.commit();
                                   }
                               }


        );
        sko.setOnClickListener(new View.OnClickListener(){

                                   @Override
                                   public void onClick(View v){
                                       Fragment newFragment = new Mark_attendance_fragment();
                                       FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack
                                       transaction.replace(R.id.fragment, newFragment);
                                       transaction.addToBackStack(null);
                                       project = 5;

// Commit the transaction
                                       transaction.commit();
                                   }
                               }


        );
        utk.setOnClickListener(new View.OnClickListener(){

                                   @Override
                                   public void onClick(View v){
                                       Fragment newFragment = new Mark_attendance_fragment();
                                       FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack
                                       transaction.replace(R.id.fragment, newFragment);
                                       transaction.addToBackStack(null);
                                       project = 6;

// Commit the transaction
                                       transaction.commit();
                                   }
                               }


        );
        disha.setOnClickListener(new View.OnClickListener(){

                                     @Override
                                     public void onClick(View v){
                                         Fragment newFragment = new Mark_attendance_fragment();
                                         FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack
                                         transaction.replace(R.id.fragment, newFragment);
                                         transaction.addToBackStack(null);
                                         project = 7;

// Commit the transaction
                                         transaction.commit();
                                     }
                                 }


        );
        un1.setOnClickListener(new View.OnClickListener(){

                                   @Override
                                   public void onClick(View v){
                                       Fragment newFragment = new Mark_attendance_fragment();
                                       FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack
                                       transaction.replace(R.id.fragment, newFragment);
                                       transaction.addToBackStack(null);
                                       project = 8;


// Commit the transaction
                                       transaction.commit();
                                   }
                               }


        );
        un2.setOnClickListener(new View.OnClickListener(){

                                   @Override
                                   public void onClick(View v){
                                       Fragment newFragment = new Mark_attendance_fragment();
                                       FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack
                                       transaction.replace(R.id.fragment, newFragment);
                                       transaction.addToBackStack(null);

// Commit the transaction
                                       transaction.commit();
                                       project = 9;
                                   }
                               }
        );
        return view;

    }

}
