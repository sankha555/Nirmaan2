package com.nirmaan_bits.nirmaan;

public class plan_holder {

    private String semPlan;

    public plan_holder(String semPlan) {
        this.semPlan = semPlan;
    }
    public plan_holder(){}


    public String getSemPlan() {
        return semPlan;
    }

    public void setSemPlan(String semPlan) {
        this.semPlan = semPlan;
    }

}
