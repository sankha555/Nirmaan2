# Nirmaan
The app helps to clearify the aim and working of all the projects in Nirmaan, BITS Pilani chapter.
